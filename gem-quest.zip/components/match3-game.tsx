"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"

type TileType = 1 | 2 | 3 | 4 | 5 | 6
type Booster = "bomb" | "switch" | "color" | null

const GRID = 8
const TYPES: TileType[] = [1, 2, 3, 4, 5, 6]
const TARGET_SCORE = 5000
const START_MOVES = 25

function randType(): TileType {
  return TYPES[Math.floor(Math.random() * TYPES.length)]
}
function idx(r: number, c: number) {
  return r * GRID + c
}
function inBounds(r: number, c: number) {
  return r >= 0 && r < GRID && c >= 0 && c < GRID
}
function swap(b: (TileType | null)[], a: number, c: number) {
  const nb = b.slice()
  ;[nb[a], nb[c]] = [nb[c], nb[a]]
  return nb
}
function iconsForType(t: TileType) {
  switch (t) {
    case 1:
      return { label: "❤" }
    case 2:
      return { label: "▲" }
    case 3:
      return { label: "◆" }
    case 4:
      return { label: "🍬" }
    case 5:
      return { label: "💎" }
    case 6:
      return { label: "★" }
  }
}
function generateInitialBoard(): (TileType | null)[] {
  const b: (TileType | null)[] = Array(GRID * GRID)
    .fill(null)
    .map(() => randType())
  const hasRunAt = (r: number, c: number) => {
    const t = b[idx(r, c)]
    if (!t) return false
    // row
    let cnt = 1
    for (let cc = c - 1; cc >= 0 && b[idx(r, cc)] === t; cc--) cnt++
    for (let cc = c + 1; cc < GRID && b[idx(r, cc)] === t; cc++) cnt++
    if (cnt >= 3) return true
    // col
    cnt = 1
    for (let rr = r - 1; rr >= 0 && b[idx(rr, c)] === t; rr--) cnt++
    for (let rr = r + 1; rr < GRID && b[idx(rr, c)] === t; rr++) cnt++
    return cnt >= 3
  }
  for (let r = 0; r < GRID; r++) {
    for (let c = 0; c < GRID; c++) {
      while (hasRunAt(r, c)) b[idx(r, c)] = randType()
    }
  }
  return b
}
function findMatches(b: (TileType | null)[]) {
  const matched = new Set<number>()
  // rows
  for (let r = 0; r < GRID; r++) {
    let start = 0
    for (let c = 1; c <= GRID; c++) {
      const prev = b[idx(r, c - 1)]
      const cur = c < GRID ? b[idx(r, c)] : null
      if (cur !== prev || prev == null) {
        const len = c - start
        if (prev != null && len >= 3) for (let k = start; k < c; k++) matched.add(idx(r, k))
        start = c
      }
    }
  }
  // cols
  for (let c = 0; c < GRID; c++) {
    let start = 0
    for (let r = 1; r <= GRID; r++) {
      const prev = b[idx(r - 1, c)]
      const cur = r < GRID ? b[idx(r, c)] : null
      if (cur !== prev || prev == null) {
        const len = r - start
        if (prev != null && len >= 3) for (let k = start; k < r; k++) matched.add(idx(k, c))
        start = r
      }
    }
  }
  return matched
}
function applyGravityAndRefill(b: (TileType | null)[]) {
  const nb = b.slice()
  for (let c = 0; c < GRID; c++) {
    let write = GRID - 1
    for (let r = GRID - 1; r >= 0; r--) {
      const i = idx(r, c)
      if (nb[i] != null) {
        nb[idx(write, c)] = nb[i]
        write--
      }
    }
    for (let r = write; r >= 0; r--) nb[idx(r, c)] = randType()
  }
  return nb
}
function neighbors(a: number, b: number) {
  const ar = Math.floor(a / GRID),
    ac = a % GRID
  const br = Math.floor(b / GRID),
    bc = b % GRID
  return Math.abs(ar - br) + Math.abs(ac - bc) === 1
}
function willMatchAfterSwap(b: (TileType | null)[], a: number, c: number) {
  const nb = swap(b, a, c)
  return findMatches(nb).size > 0
}
function hasAnyValidMove(b: (TileType | null)[]) {
  for (let r = 0; r < GRID; r++) {
    for (let c = 0; c < GRID; c++) {
      const i = idx(r, c)
      if (c + 1 < GRID && willMatchAfterSwap(b, i, idx(r, c + 1))) return true
      if (r + 1 < GRID && willMatchAfterSwap(b, i, idx(r + 1, c))) return true
    }
  }
  return false
}

export default function Game() {
  const [board, setBoard] = useState<(TileType | null)[]>(() => generateInitialBoard())
  const [score, setScore] = useState(5000)
  const [movesLeft, setMovesLeft] = useState(START_MOVES)
  const [level] = useState(15)
  const [selected, setSelected] = useState<number | null>(null)
  const [musicOn, setMusicOn] = useState(true)
  const [love, setLove] = useState(72)
  const [showVictory, setShowVictory] = useState(false)
  const [activeBooster, setActiveBooster] = useState<Booster>(null)
  const isProcessingRef = useRef(false)
  const bgmRef = useRef<HTMLAudioElement>(null)
  const matchRef = useRef<HTMLAudioElement>(null)
  const powerRef = useRef<HTMLAudioElement>(null)
  const levelRef = useRef<HTMLAudioElement>(null)

  // Mirror header text and bind music toggle
  useEffect(() => {
    const hs = document.getElementById("header-score")
    const hl = document.getElementById("header-level")
    if (hs) hs.textContent = `${score.toLocaleString()} pts`
    if (hl) hl.textContent = `Level ${level}`
  }, [score, level])
  useEffect(() => {
    const btn = document.getElementById("header-music")
    const label = btn?.querySelector("span:last-child")
    if (label) label.textContent = musicOn ? "Music On" : "Music Off"
  }, [musicOn])
  useEffect(() => {
    const btn = document.getElementById("header-music")
    if (!btn) return
    const onClick = () => setMusicOn((s) => !s)
    btn.addEventListener("click", onClick)
    return () => btn.removeEventListener("click", onClick)
  }, [])

  useEffect(() => {
    if (!hasAnyValidMove(board)) doShuffle()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const a = bgmRef.current
    if (!a) return
    a.volume = 0.5
    if (musicOn) {
      a.play().catch(() => {})
    } else {
      a.pause()
      a.currentTime = 0
    }
  }, [musicOn])

  useEffect(() => {
    if (showVictory && levelRef.current) {
      levelRef.current.currentTime = 0
      levelRef.current.play().catch(() => {})
    }
  }, [showVictory])

  const notify = useCallback((text: string) => {
    const div = document.createElement("div")
    div.textContent = text
    Object.assign(div.style, {
      position: "fixed",
      bottom: "6rem",
      left: "50%",
      transform: "translateX(-50%)",
      background: "rgba(0,0,0,0.6)",
      padding: "0.6rem 1rem",
      borderRadius: "8px",
      zIndex: "2000",
    } as CSSStyleDeclaration)
    document.body.appendChild(div)
    setTimeout(() => div.remove(), 1600)
  }, [])

  const processMatchesCascade = useCallback(async (start: (TileType | null)[]) => {
    let b = start.slice()
    let combo = 0
    while (true) {
      const matched = findMatches(b)
      if (matched.size === 0) break
      combo++
      // sfx
      if (matchRef.current) {
        matchRef.current.currentTime = 0
        matchRef.current.play().catch(() => {})
      }
      const gained = matched.size * (50 + (combo - 1) * 10)
      setScore((s) => s + gained)
      matched.forEach((i) => (b[i] = null))
      b = applyGravityAndRefill(b)
      await new Promise((r) => setTimeout(r, 120))
      setBoard(b)
    }
    if (combo > 0) setLove((v) => Math.min(100, v + Math.min(10, combo * 2)))
    return b
  }, [])

  const handleTileClick = useCallback(
    async (i: number) => {
      if (isProcessingRef.current) return

      // Booster: bomb
      if (activeBooster === "bomb") {
        isProcessingRef.current = true
        setActiveBooster(null)
        const r = Math.floor(i / GRID),
          c = i % GRID
        const toClear = new Set<number>()
        for (let dr = -1; dr <= 1; dr++)
          for (let dc = -1; dc <= 1; dc++) {
            const rr = r + dr,
              cc = c + dc
            if (inBounds(rr, cc)) toClear.add(idx(rr, cc))
          }
        const b = board.slice()
        toClear.forEach((p) => (b[p] = null))
        setBoard(b)
        if (powerRef.current) {
          powerRef.current.currentTime = 0
          powerRef.current.play().catch(() => {})
        }
        const after = await processMatchesCascade(applyGravityAndRefill(b))
        setLove((v) => Math.min(100, v + 3))
        const newMoves = Math.max(0, movesLeft - 1)
        setMovesLeft(newMoves)
        if (score >= TARGET_SCORE || newMoves <= 0) {
          setShowVictory(true)
        } else if (!hasAnyValidMove(after)) {
          notify("No moves — Shuffling")
          doShuffleWithBoard(after)
        }
        isProcessingRef.current = false
        return
      }

      // Booster: color (clear all of that type)
      if (activeBooster === "color") {
        isProcessingRef.current = true
        setActiveBooster(null)
        const t = board[i]
        const b = board.map((x) => (x === t ? null : x))
        setBoard(b)
        if (powerRef.current) {
          powerRef.current.currentTime = 0
          powerRef.current.play().catch(() => {})
        }
        const after = await processMatchesCascade(applyGravityAndRefill(b))
        setLove((v) => Math.min(100, v + 3))
        const newMoves = Math.max(0, movesLeft - 1)
        setMovesLeft(newMoves)
        if (score >= TARGET_SCORE || newMoves <= 0) {
          setShowVictory(true)
        } else if (!hasAnyValidMove(after)) {
          notify("No moves — Shuffling")
          doShuffleWithBoard(after)
        }
        isProcessingRef.current = false
        return
      }

      // Booster: switch (select any two; must create a match)
      if (activeBooster === "switch") {
        if (selected == null) {
          setSelected(i)
          return
        } else {
          isProcessingRef.current = true
          setActiveBooster(null)
          const a = selected
          setSelected(null)
          const nb = swap(board, a, i)
          if (findMatches(nb).size > 0) {
            setBoard(nb)
            await processMatchesCascade(nb)
            setLove((v) => Math.min(100, v + 3))
            const newMoves = Math.max(0, movesLeft - 1)
            setMovesLeft(newMoves)
            if (score >= TARGET_SCORE || newMoves <= 0) {
              setShowVictory(true)
            } else if (!hasAnyValidMove(nb)) {
              notify("No moves — Shuffling")
              doShuffleWithBoard(nb)
            }
          } else {
            notify("Switch must create a match")
          }
          isProcessingRef.current = false
          return
        }
      }

      // Normal adjacent swap
      if (selected == null) {
        setSelected(i)
        return
      }
      if (!neighbors(selected, i)) {
        setSelected(i)
        return
      }
      if (!willMatchAfterSwap(board, selected, i)) {
        setSelected(null)
        notify("No match — invalid move")
        return
      }
      isProcessingRef.current = true
      const nb = swap(board, selected, i)
      setSelected(null)
      setBoard(nb)
      await processMatchesCascade(nb)
      setMovesLeft((m) => Math.max(0, m - 1))
      isProcessingRef.current = false
    },
    [board, selected, activeBooster, notify, processMatchesCascade],
  )

  const doShuffleWithBoard = useCallback((b: (TileType | null)[]) => {
    const tiles = b.filter((x) => x != null) as TileType[]
    for (let i = tiles.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[tiles[i], tiles[j]] = [tiles[j], tiles[i]]
    }
    let k = 0
    let nb = b.map((x) => (x == null ? randType() : tiles[k++]))
    let guard = 0
    while (!hasAnyValidMove(nb) && guard < 200) {
      for (let i = tiles.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[tiles[i], tiles[j]] = [tiles[j], tiles[i]]
      }
      k = 0
      nb = b.map((x) => (x == null ? randType() : tiles[k++]))
      guard++
    }
    setBoard(nb)
  }, [])
  const doShuffle = useCallback(() => {
    notify("Board shuffled")
    doShuffleWithBoard(board)
  }, [board, notify, doShuffleWithBoard])

  const handleMatchButton = useCallback(async () => {
    if (isProcessingRef.current) return
    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) {
        const i = idx(r, c)
        const right = c + 1 < GRID ? idx(r, c + 1) : -1
        const down = r + 1 < GRID ? idx(r + 1, c) : -1
        if (right !== -1 && willMatchAfterSwap(board, i, right)) {
          isProcessingRef.current = true
          const nb = swap(board, i, right)
          setBoard(nb)
          await processMatchesCascade(nb)
          setMovesLeft((m) => Math.max(0, m - 1))
          isProcessingRef.current = false
          return
        }
        if (down !== -1 && willMatchAfterSwap(board, i, down)) {
          isProcessingRef.current = true
          const nb = swap(board, i, down)
          setBoard(nb)
          await processMatchesCascade(nb)
          setMovesLeft((m) => Math.max(0, m - 1))
          isProcessingRef.current = false
          return
        }
      }
    }
    notify("No valid matches — Shuffling")
    doShuffle()
  }, [board, doShuffle, notify, processMatchesCascade])

  const selectBooster = useCallback(
    (b: Booster) => {
      setActiveBooster((prev) => (prev === b ? null : b))
      if (b) notify(`Booster selected: ${b}`)
    },
    [notify],
  )

  const tileClasses = useMemo(
    () => ({
      1: "bg-gradient-to-b from-rose-500 to-pink-500",
      2: "bg-gradient-to-b from-amber-500 to-yellow-400",
      3: "bg-gradient-to-b from-sky-500 to-blue-500",
      4: "bg-gradient-to-b from-violet-500 to-fuchsia-500",
      5: "bg-gradient-to-b from-emerald-500 to-green-400",
      6: "bg-gradient-to-b from-fuchsia-500 to-rose-500",
    }),
    [],
  )

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-6">
      {/* Left: Game panel */}
      <section className="bg-gradient-to-br from-indigo-800 to-indigo-500 rounded-2xl p-4 md:p-6 shadow-2xl border border-white/10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-yellow-100">Level {level}: Crystal Cave</h2>
            <p className="text-cyan-200 text-sm">Match gems to collect treasures!</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="rounded-full bg-indigo-900/80 px-4 py-2 text-sm">
              MOVES <span className="font-bold text-yellow-200 ml-1">{movesLeft}</span>/{START_MOVES}
            </div>
            <div className="rounded-full bg-indigo-900/80 px-4 py-2 text-sm">
              TARGET <span className="font-bold text-yellow-200 ml-1">{TARGET_SCORE.toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="rounded-xl p-3 bg-indigo-900/50 shadow-inner mb-4">
          <div className="grid grid-cols-8 gap-2">
            {board.map((t, i) => {
              const sel = selected === i
              return (
                <button
                  key={i}
                  onClick={() => handleTileClick(i)}
                  className={[
                    "aspect-square rounded-xl flex items-center justify-center text-2xl shadow-lg transition-transform hover:-translate-y-0.5",
                    t ? tileClasses[t] : "bg-indigo-700",
                    sel ? "ring-4 ring-yellow-200" : "",
                  ].join(" ")}
                  aria-label={`tile ${i}`}
                >
                  <span>{t ? iconsForType(t)?.label : ""}</span>
                </button>
              )
            })}
          </div>
        </div>

        <div className="flex gap-3">
          <button
            className="flex-1 h-12 rounded-xl bg-gradient-to-r from-sky-500 to-blue-500 font-bold shadow hover:-translate-y-0.5 transition"
            onClick={doShuffle}
            id="shuffle-btn"
          >
            <span className="mr-2" aria-hidden="true">
              🔀
            </span>
            SHUFFLE
          </button>
          <button
            className="flex-1 h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 font-bold shadow hover:-translate-y-0.5 transition"
            onClick={handleMatchButton}
            id="match-btn"
          >
            <span className="mr-2" aria-hidden="true">
              ✨
            </span>
            MATCH
          </button>
        </div>
      </section>

      {/* Right: Side panel */}
      <div className="flex flex-col gap-6">
        {/* Video Call Card (placeholder) */}
        <section className="rounded-2xl p-4 md:p-6 shadow-xl border border-white/10 bg-gradient-to-br from-purple-800 to-purple-400">
          <div className="flex items-center gap-2 mb-4">
            <span aria-hidden="true">📹</span>
            <h3 className="text-yellow-100 font-semibold">Video Call</h3>
          </div>

          <div className="flex flex-col md:flex-row gap-3 mb-4">
            <div className="flex-1 rounded-xl overflow-hidden shadow-lg">
              <div className="h-40 flex items-center justify-center bg-gradient-to-br from-rose-500 to-orange-500">
                <span aria-hidden="true" className="text-4xl">
                  👤
                </span>
              </div>
              <div className="text-center text-sm bg-black/40 py-1">Priya</div>
            </div>
            <div className="flex-1 rounded-xl overflow-hidden shadow-lg">
              <div className="h-40 flex items-center justify-center bg-gradient-to-br from-sky-500 to-blue-500">
                <span aria-hidden="true" className="text-4xl">
                  👤
                </span>
              </div>
              <div className="text-center text-sm bg-black/40 py-1">Rahul</div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 mb-4">
            {["V5", "V3", "V2", "V1", "V0", "VOICE"].map((t, i) => (
              <button
                key={t}
                className={`text-sm font-semibold rounded-lg px-2 py-2 border border-white/10 bg-white/15 hover:bg-white/25 transition ${i === 0 ? "ring-2 ring-yellow-100" : ""}`}
                onClick={() => {}}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              className="h-12 rounded-xl bg-gradient-to-r from-sky-500 to-blue-500 font-bold shadow hover:-translate-y-0.5 transition"
              onClick={() => {
                notify("VOICE CALL: Calling...")
                setLove((v) => Math.min(100, v + 1))
              }}
              id="voice-call-btn"
            >
              <span className="mr-2" aria-hidden="true">
                📞
              </span>
              VOICE CALL
            </button>
            <button
              className="h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 font-bold shadow hover:-translate-y-0.5 transition"
              onClick={() => {
                notify("VIDEO CALL: Starting...")
                setLove((v) => Math.min(100, v + 1))
              }}
              id="video-call-btn"
            >
              <span className="mr-2" aria-hidden="true">
                📹
              </span>
              VIDEO CALL
            </button>
          </div>
        </section>

        {/* Love Meter */}
        <section className="rounded-2xl p-4 md:p-6 shadow-xl border border-white/10 bg-gradient-to-br from-red-700 to-rose-400">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-yellow-100 font-semibold">
              <span aria-hidden="true" className="mr-2">
                ❤️
              </span>
              Love Meter
            </h3>
            <div className="font-bold text-yellow-200">{love}%</div>
          </div>
          <div className="h-5 bg-white/25 rounded-lg overflow-hidden shadow-inner mb-3">
            <div
              className="h-full bg-gradient-to-r from-yellow-100 via-yellow-200 to-amber-500"
              style={{ width: `${love}%` }}
            />
          </div>
          <p className="text-rose-100 text-sm mb-2">Play together to fill the love meter!</p>
          <div className="flex items-center gap-2 text-yellow-100 text-sm">
            <span aria-hidden="true">🎁</span>
            <span>
              Unlock <strong>Heart Candy</strong> at 100%.
            </span>
          </div>
        </section>

        {/* Boosters */}
        <section className="rounded-2xl p-4 md:p-6 shadow-xl border border-white/10 bg-gradient-to-br from-emerald-700 to-green-400">
          <div className="flex items-center gap-2 mb-4">
            <span aria-hidden="true">✨</span>
            <h3 className="text-yellow-100 font-semibold">Boosters</h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <button
              className={`rounded-xl p-4 text-center border border-white/10 bg-white/15 hover:bg-white/25 transition ${activeBooster === "bomb" ? "ring-2 ring-yellow-100" : ""}`}
              onClick={() => selectBooster("bomb")}
              data-booster="bomb"
            >
              <div className="text-2xl mb-1">💣</div>
              <div className="text-sm font-semibold text-yellow-100">Bomb</div>
            </button>
            <button
              className={`rounded-xl p-4 text-center border border-white/10 bg-white/15 hover:bg-white/25 transition ${activeBooster === "switch" ? "ring-2 ring-yellow-100" : ""}`}
              onClick={() => selectBooster("switch")}
              data-booster="switch"
            >
              <div className="text-2xl mb-1">🔀</div>
              <div className="text-sm font-semibold text-yellow-100">Switch</div>
            </button>
            <button
              className={`rounded-xl p-4 text-center border border-white/10 bg-white/15 hover:bg-white/25 transition ${activeBooster === "color" ? "ring-2 ring-yellow-100" : ""}`}
              onClick={() => selectBooster("color")}
              data-booster="color"
            >
              <div className="text-2xl mb-1">✨</div>
              <div className="text-sm font-semibold text-yellow-100">Color</div>
            </button>
          </div>
        </section>
      </div>

      {/* Enjoy ribbon */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-500 px-8 py-3 rounded-full font-extrabold text-xl shadow-2xl animate-bounce">
        ENJOY ✨
      </div>

      {/* Victory modal */}
      {showVictory && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gradient-to-b from-purple-800 to-blue-600 rounded-2xl p-6 w-[90%] max-w-md shadow-2xl border border-white/20">
            <div className="w-20 h-20 rounded-full mx-auto mb-3 flex items-center justify-center bg-gradient-to-br from-rose-500 to-pink-600 shadow-lg">
              <span className="text-3xl">🏆</span>
            </div>
            <h2 className="text-center text-2xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-yellow-100 to-yellow-200 mb-2">
              LEVEL COMPLETED!
            </h2>
            <p className="text-center text-indigo-100 mb-4">Score: {score.toLocaleString()} • Stars: ⭐⭐⭐</p>
            <button
              className="w-full h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 font-bold shadow hover:-translate-y-0.5 transition"
              onClick={() => setShowVictory(false)}
              id="continue-btn"
            >
              CONTINUE
            </button>
          </div>
        </div>
      )}

      <audio ref={bgmRef} src="/audio/background_music.ogg" loop className="hidden" />
      <audio ref={matchRef} src="/audio/match_sound.mp3" className="hidden" />
      <audio ref={powerRef} src="/audio/powerup_blast.wav" className="hidden" />
      <audio ref={levelRef} src="/audio/level_complete.mp3" className="hidden" />
    </div>
  )
}
