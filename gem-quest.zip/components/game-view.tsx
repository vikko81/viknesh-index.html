"use client"

import { useEffect, useRef, useState } from "react"
import { cn } from "@/lib/utils"
import "../styles/combo_animations.css"
import "../styles/ui_animations.css"
import "../styles/tile_animations.css"
import * as Engine from "@/game/game_engine"

// Colors used in UI (3-5 total, solid colors per design rules)
const COLORS = {
  primary: "#0ea5e9", // sky-500
  neutralBg: "var(--background)",
  neutralFg: "var(--foreground)",
  accent: "#f59e0b", // amber-500
}

type Tile = number | null

export default function GameView() {
  const [engine, setEngine] = useState<Engine.GameEngine | null>(null)
  const [board, setBoard] = useState<Tile[][]>([])
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [moves, setMoves] = useState(0)
  const [target, setTarget] = useState(1000)
  const [love, setLove] = useState(0) // 0-100
  const [musicOn, setMusicOn] = useState(false)
  const [victory, setVictory] = useState<{ win: boolean; open: boolean }>({ win: false, open: false })
  const [selected, setSelected] = useState<{ r: number; c: number } | null>(null)
  const [activeBooster, setActiveBooster] = useState<"bomb" | "switch" | "color" | null>(null)
  const colorPickRef = useRef<number | null>(null)
  const bgmRef = useRef<HTMLAudioElement>(null)

  // Initialize game engine once
  useEffect(() => {
    const eng = new Engine.GameEngine({
      rows: 8,
      cols: 8,
      numColors: 6,
      onUpdate: (s) => {
        setBoard(s.board)
        setScore(s.score)
        setMoves(s.movesRemaining)
        setTarget(s.targetScore)
        setLevel(s.level)
        setLove(s.love)
      },
      onWin: () => setVictory({ win: true, open: true }),
      onLose: () => setVictory({ win: false, open: true }),
    })
    eng.start(1)
    setEngine(eng)
    return () => eng.dispose()
  }, [])

  // Music toggle
  useEffect(() => {
    if (!bgmRef.current) return
    if (musicOn) {
      void bgmRef.current.play().catch(() => {})
    } else {
      bgmRef.current.pause()
      bgmRef.current.currentTime = 0
    }
  }, [musicOn])

  const onTileClick = (r: number, c: number) => {
    if (!engine) return
    if (activeBooster === "bomb") {
      setActiveBooster(null)
      return
    }
    if (activeBooster === "color") {
      // On first click, remember color; on second click, clear that color
      const tile = board[r]?.[c]
      if (tile == null) return
      if (colorPickRef.current == null) {
        colorPickRef.current = tile
        // brief feedback
        return
      } else {
        colorPickRef.current = null
        setActiveBooster(null)
        return
      }
    }
    // Normal or "switch" booster swap
    if (!selected) {
      setSelected({ r, c })
      return
    }
    const sr = selected.r
    const sc = selected.c
    setSelected(null)
    if (activeBooster === "switch") {
      setActiveBooster(null)
      return
    }
    engine.trySwap(sr, sc, r, c)
  }

  const useBomb = (r: number, c: number) => {
    if (!engine) return
    engine.useBomb(r, c)
  }

  const shuffle = () => {
    engine?.shuffle()
  }
  const autoMatch = () => {
    engine?.autoHintAndPlay()
  }
  const nextLevel = () => {
    setVictory({ win: false, open: false })
    engine?.start(level + 1)
  }
  const retry = () => {
    setVictory({ win: false, open: false })
    engine?.start(level)
  }

  const lovePct = Math.max(0, Math.min(100, love))

  return (
    <div className="grid gap-6 md:grid-cols-[1fr_320px]">
      {/* Left: Game area */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="rounded border px-3 py-1 text-sm">Level: {level}</div>
            <div className="rounded border px-3 py-1 text-sm">Score: {score}</div>
            <div className="rounded border px-3 py-1 text-sm">Target: {target}</div>
            <div className="rounded border px-3 py-1 text-sm">Moves: {moves}</div>
          </div>
          <button
            className="rounded px-3 py-1 text-sm border hover:bg-accent/10"
            onClick={() => setMusicOn((s) => !s)}
            aria-pressed={musicOn}
          >
            {musicOn ? "Music: On" : "Music: Off"}
          </button>
        </div>

        {/* Board */}
        <div
          className="grid gap-1 p-2 rounded-lg border bg-card"
          style={{ gridTemplateColumns: `repeat(${board[0]?.length || 8}, minmax(0, 1fr))` }}
          role="grid"
          aria-label="Match-3 Board"
        >
          {board.map((row, rIdx) =>
            row.map((tile, cIdx) => {
              const isSel = selected?.r === rIdx && selected?.c === cIdx
              return (
                <button
                  key={`${rIdx}-${cIdx}`}
                  role="gridcell"
                  aria-label={`Tile ${rIdx},${cIdx}`}
                  onClick={() => {
                    if (activeBooster === "bomb") {
                      useBomb(rIdx, cIdx)
                    } else {
                      onTileClick(rIdx, cIdx)
                    }
                  }}
                  className={cn(
                    "relative aspect-square rounded-md flex items-center justify-center overflow-hidden outline-none transition-colors",
                    "tile-transition",
                    isSel ? "ring-2 ring-sky-500" : "ring-0",
                  )}
                  style={{
                    background: tile == null ? "transparent" : `url(/assets/candy_sprites.png)`,
                    backgroundSize: "512px 512px",
                    backgroundPosition: tile == null ? "0 0" : Engine.spritePos(tile),
                  }}
                >
                  <span className="sr-only">{tile == null ? "empty" : `type ${tile}`}</span>
                </button>
              )
            }),
          )}
        </div>

        {/* Controls */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button onClick={shuffle} className="rounded bg-sky-500 text-white px-3 py-2 text-sm hover:bg-sky-600">
            SHUFFLE
          </button>
          <button onClick={autoMatch} className="rounded bg-amber-500 text-black px-3 py-2 text-sm hover:bg-amber-600">
            MATCH
          </button>
          <div className="mx-3 h-6 w-px bg-muted" />
          <button
            onClick={() => setActiveBooster("bomb")}
            className={cn("rounded border px-3 py-2 text-sm hover:bg-muted", activeBooster === "bomb" && "bg-muted")}
          >
            Bomb
          </button>
          <button
            onClick={() => setActiveBooster("switch")}
            className={cn("rounded border px-3 py-2 text-sm hover:bg-muted", activeBooster === "switch" && "bg-muted")}
          >
            Switch
          </button>
          <button
            onClick={() => {
              colorPickRef.current = null
              setActiveBooster("color")
            }}
            className={cn("rounded border px-3 py-2 text-sm hover:bg-muted", activeBooster === "color" && "bg-muted")}
          >
            Color
          </button>
        </div>

        {/* Love Meter */}
        <div className="mt-4">
          <label htmlFor="love" className="text-sm block mb-1">
            Love Meter
          </label>
          <div className="w-full h-3 rounded bg-muted overflow-hidden">
            <div
              id="love"
              className="h-3 bg-pink-500 transition-all"
              style={{ width: `${lovePct}%` }}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={lovePct}
              role="progressbar"
            />
          </div>
        </div>
      </div>

      {/* Right: Info / Audio */}
      <aside className="space-y-4">
        <div className="rounded-lg border p-3">
          <h2 className="font-medium mb-2">How to play</h2>
          <ul className="text-sm list-disc pl-4 space-y-1">
            <li>Adjacent swap to make 3+ in a row/column.</li>
            <li>Bomb: tap Bomb, then a tile to clear 3×3.</li>
            <li>Switch: tap two tiles to swap anywhere.</li>
            <li>Color: tap Color, choose a tile color, then tap any tile to clear all of that color.</li>
            <li>Match finds and plays a valid move for you.</li>
          </ul>
        </div>

        <audio ref={bgmRef} src="/audio/background_music.ogg" loop />

        <div className="rounded-lg border p-3">
          <h2 className="font-medium mb-2">Assets</h2>
          <div className="flex items-center gap-2 text-sm">
            <img src="/assets/fruit_icons.png" alt="Fruit Icons" className="h-8 w-8 rounded" />
            <span className="opacity-70">Sprites & Sounds are placeholders — replace any time.</span>
          </div>
        </div>
      </aside>

      {/* Victory / Lose Modal */}
      {victory.open && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-background text-foreground rounded-lg p-6 w-full max-w-sm ui-pop">
            <h3 className="text-lg font-semibold mb-2">{victory.win ? "Level Complete!" : "Out of Moves"}</h3>
            <p className="text-sm mb-4">
              {victory.win ? "Great job! Move on to the next level." : "Try again to reach the target score."}
            </p>
            <div className="flex gap-2">
              {victory.win ? (
                <button onClick={nextLevel} className="rounded bg-sky-500 text-white px-3 py-2 text-sm">
                  Next Level
                </button>
              ) : (
                <button onClick={retry} className="rounded bg-sky-500 text-white px-3 py-2 text-sm">
                  Retry
                </button>
              )}
              <button
                onClick={() => setVictory({ win: false, open: false })}
                className="rounded border px-3 py-2 text-sm"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
