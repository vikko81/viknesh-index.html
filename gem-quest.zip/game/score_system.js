export function pointsForMatch(matchCount, chainIndex) {
  const basePerTile = 20 + chainIndex * 10
  return basePerTile * matchCount
}
export function addToScore(current, tilesCleared, chainIndex) {
  return current + pointsForMatch(tilesCleared, chainIndex)
}
