import {
  createBoard,
  findMatches,
  collapse,
  refill,
  swapIfAdjacent,
  hasAnyMoves,
  findHint,
  applyBomb,
  applyColorClear,
  spritePos as _spritePos,
} from "./match3_logic"
import { addToScore } from "./score_system"
import { loadLevels, getLevel } from "./level_manager"

export function spritePos(tile) {
  return _spritePos(tile)
}

export class GameEngine {
  constructor(opts) {
    this.rows = opts.rows
    this.cols = opts.cols
    this.numColors = opts.numColors
    this._onUpdate = opts.onUpdate
    this._onWin = opts.onWin
    this._onLose = opts.onLose
    this._disposed = false

    this.levels = []
    this.state = {
      level: 1,
      targetScore: 1000,
      movesRemaining: 20,
      score: 0,
      love: 0,
      board: createBoard(this.rows, this.cols, this.numColors),
    }
  }

  async start(levelNumber = 1) {
    if (!this.levels.length) {
      this.levels = await loadLevels()
    }
    const lvl = getLevel(this.levels, levelNumber)
    this.state.level = levelNumber
    this.state.targetScore = lvl.target
    this.state.movesRemaining = lvl.moves
    this.numColors = lvl.numColors || this.numColors
    this.state.score = 0
    this.state.love = 0
    this.state.board = createBoard(this.rows, this.cols, this.numColors)
    this._emit()
  }

  dispose() {
    this._disposed = true
  }

  _emit() {
    if (this._disposed) return
    this._onUpdate?.({ ...this.state })
    if (this.state.score >= this.state.targetScore) {
      this._onWin?.()
    } else if (this.state.movesRemaining <= 0 && this.state.score < this.state.targetScore) {
      this._onLose?.()
    }
  }

  async trySwap(r1, c1, r2, c2) {
    if (this.state.movesRemaining <= 0) return
    const { swapped, board } = swapIfAdjacent(this.state.board, r1, c1, r2, c2)
    if (!swapped) return
    const matches = findMatches(board)
    if (matches.size === 0) return // invalid swap; do nothing
    this.state.board = board
    this.state.movesRemaining--
    await this._resolve()
  }

  async _resolve() {
    let chain = 0
    while (true) {
      const matches = findMatches(this.state.board)
      if (matches.size === 0) break
      chain++
      let cleared = 0
      const b = this.state.board.map((row) => row.slice())
      matches.forEach((key) => {
        const [r, c] = key.split(",").map(Number)
        if (b[r][c] != null) {
          b[r][c] = null
          cleared++
        }
      })
      this.state.score = addToScore(this.state.score, cleared, chain - 1)
      this.state.love = Math.min(100, this.state.love + Math.ceil(cleared / 2))
      this.state.board = collapse(b)
      this._emit()
      await delay(60)
      this.state.board = refill(this.state.board, this.numColors)
      this._emit()
      await delay(60)
    }
    if (!hasAnyMoves(this.state.board, this.numColors)) {
      await this.shuffle()
    } else {
      this._emit()
    }
  }

  async shuffle() {
    let b
    do {
      b = createBoard(this.rows, this.cols, this.numColors)
    } while (!hasAnyMoves(b, this.numColors))
    this.state.board = b
    this._emit()
  }

  async autoHintAndPlay() {
    if (this.state.movesRemaining <= 0) return
    const hint = findHint(this.state.board)
    if (!hint) {
      await this.shuffle()
      return
    }
    const { r1, c1, r2, c2 } = hint
    const { swapped, board } = swapIfAdjacent(this.state.board, r1, c1, r2, c2)
    if (!swapped) return
    this.state.board = board
    this.state.movesRemaining--
    await this._resolve()
  }

  async useBomb(r, c) {
    if (this.state.movesRemaining <= 0) return
    const area = applyBomb(this.state.board, r, c, 1)
    const b = this.state.board.map((row) => row.slice())
    let cleared = 0
    area.forEach((key) => {
      const [rr, cc] = key.split(",").map(Number)
      if (b[rr][cc] != null) {
        b[rr][cc] = null
        cleared++
      }
    })
    this.state.board = collapse(b)
    this.state.movesRemaining--
    this.state.score = addToScore(this.state.score, cleared, 0)
    this.state.love = Math.min(100, this.state.love + Math.ceil(cleared / 2))
    this._emit()
    await delay(60)
    this.state.board = refill(this.state.board, this.numColors)
    await this._resolve()
  }

  async useSwitch(r1, c1, r2, c2) {
    if (this.state.movesRemaining <= 0) return
    const b = this.state.board.map((row) => row.slice())
    const tmp = b[r1][c1]
    b[r1][c1] = b[r2][c2]
    b[r2][c2] = tmp
    this.state.board = b
    this.state.movesRemaining--
    this._emit()
    await this._resolve()
  }

  async useColorClear(color) {
    if (this.state.movesRemaining <= 0) return
    const area = applyColorClear(this.state.board, color)
    const b = this.state.board.map((row) => row.slice())
    let cleared = 0
    area.forEach((key) => {
      const [rr, cc] = key.split(",").map(Number)
      if (b[rr][cc] != null) {
        b[rr][cc] = null
        cleared++
      }
    })
    this.state.board = collapse(b)
    this.state.movesRemaining--
    this.state.score = addToScore(this.state.score, cleared, 0)
    this.state.love = Math.min(100, this.state.love + Math.ceil(cleared / 2))
    this._emit()
    await delay(60)
    this.state.board = refill(this.state.board, this.numColors)
    await this._resolve()
  }
}

function delay(ms) {
  return new Promise((res) => setTimeout(res, ms))
}
