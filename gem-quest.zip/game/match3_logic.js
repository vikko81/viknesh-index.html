export function spritePos(tile) {
  // tile index maps to 64x64 cell within a 512x512 (8x8) sprite sheet
  const size = 64
  const cols = 8
  const x = (tile % cols) * -size
  const y = Math.floor(tile / cols) * -size
  return `${x}px ${y}px`
}

export function emptyBoard(rows, cols) {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => null))
}

export function randTile(colors) {
  return Math.floor(Math.random() * colors)
}

export function createBoard(rows, cols, colors) {
  const b = emptyBoard(rows, cols)
  // fill avoiding immediate matches and ensuring at least one move
  do {
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        b[r][c] = randTile(colors)
      }
    }
  } while (findMatches(b).size > 0 || !hasAnyMoves(b, colors))
  return b
}

export function findMatches(board) {
  const rows = board.length
  const cols = board[0].length
  const toClear = new Set()

  // Horizontal
  for (let r = 0; r < rows; r++) {
    let runStart = 0
    for (let c = 1; c <= cols; c++) {
      if (c < cols && board[r][c] != null && board[r][c] === board[r][c - 1]) continue
      const len = c - runStart
      if (len >= 3) {
        for (let k = runStart; k < c; k++) toClear.add(`${r},${k}`)
      }
      runStart = c
    }
  }
  // Vertical
  for (let c = 0; c < cols; c++) {
    let runStart = 0
    for (let r = 1; r <= rows; r++) {
      if (r < rows && board[r][c] != null && board[r][c] === board[r - 1][c]) continue
      const len = r - runStart
      if (len >= 3) {
        for (let k = runStart; k < r; k++) toClear.add(`${k},${c}`)
      }
      runStart = r
    }
  }

  return toClear
}

export function swapIfAdjacent(board, r1, c1, r2, c2) {
  const rows = board.length
  const cols = board[0].length
  if (r1 < 0 || r1 >= rows || r2 < 0 || r2 >= rows || c1 < 0 || c1 >= cols || c2 < 0 || c2 >= cols)
    return { swapped: false }
  const dr = Math.abs(r1 - r2)
  const dc = Math.abs(c1 - c2)
  if (dr + dc !== 1) return { swapped: false }
  const nb = board.map((row) => row.slice())
  const tmp = nb[r1][c1]
  nb[r1][c1] = nb[r2][c2]
  nb[r2][c2] = tmp
  return { swapped: true, board: nb }
}

export function collapse(board) {
  const rows = board.length
  const cols = board[0].length
  const nb = board.map((row) => row.slice())

  for (let c = 0; c < cols; c++) {
    let write = rows - 1
    for (let r = rows - 1; r >= 0; r--) {
      if (nb[r][c] != null) {
        nb[write][c] = nb[r][c]
        write--
      }
    }
    for (let r = write; r >= 0; r--) nb[r][c] = null
  }
  return nb
}

export function refill(board, colors) {
  const rows = board.length
  const cols = board[0].length
  const nb = board.map((row) => row.slice())

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (nb[r][c] == null) nb[r][c] = randTile(colors)
    }
  }
  return nb
}

export function hasAnyMoves(board) {
  const rows = board.length
  const cols = board[0].length
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (c + 1 < cols) {
        const { swapped, board: b } = swapIfAdjacent(board, r, c, r, c + 1)
        if (swapped && findMatches(b).size > 0) return true
      }
      if (r + 1 < rows) {
        const { swapped, board: b } = swapIfAdjacent(board, r, c, r + 1, c)
        if (swapped && findMatches(b).size > 0) return true
      }
    }
  }
  return false
}

export function findHint(board) {
  const rows = board.length
  const cols = board[0].length
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (c + 1 < cols) {
        const { swapped, board: b } = swapIfAdjacent(board, r, c, r, c + 1)
        if (swapped && findMatches(b).size > 0) return { r1: r, c1: c, r2: r, c2: c + 1 }
      }
      if (r + 1 < rows) {
        const { swapped, board: b } = swapIfAdjacent(board, r, c, r + 1, c)
        if (swapped && findMatches(b).size > 0) return { r1: r, c1: c, r2: r + 1, c2: c }
      }
    }
  }
  return null
}

export function applyBomb(board, r, c, radius = 1) {
  const rows = board.length
  const cols = board[0].length
  const clear = new Set()
  for (let i = r - radius; i <= r + radius; i++) {
    for (let j = c - radius; j <= c + radius; j++) {
      if (i >= 0 && i < rows && j >= 0 && j < cols) clear.add(`${i},${j}`)
    }
  }
  return clear
}

export function applyColorClear(board, color) {
  const rows = board.length
  const cols = board[0].length
  const clear = new Set()
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (board[r][c] === color) clear.add(`${r},${c}`)
    }
  }
  return clear
}
