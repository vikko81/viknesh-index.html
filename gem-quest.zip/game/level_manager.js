export async function loadLevels() {
  const res = await fetch("/data/levels_config.json")
  const data = await res.json()
  return data.levels
}
export function getLevel(levels, n) {
  const idx = Math.max(0, Math.min(levels.length - 1, n - 1))
  return levels[idx]
}
