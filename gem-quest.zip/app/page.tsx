"use client"
import Game from "@/components/match3-game"

export default function Page() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-teal-700 via-cyan-700 to-indigo-800 text-white p-4">
      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <header className="bg-gradient-to-r from-indigo-800 via-indigo-500 to-blue-500 rounded-2xl p-4 md:p-6 mb-6 shadow-xl border border-white/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="rounded-xl p-3 bg-gradient-to-br from-pink-500 to-rose-500 shadow-lg">
                <span aria-hidden="true">❤️</span>
              </div>
              <div>
                <h1 className="text-2xl font-extrabold text-yellow-100 text-pretty">Gem Quest Adventure</h1>
                <p className="text-cyan-200 text-sm">Love & Call Edition</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="rounded-full bg-indigo-900/70 px-4 py-2 text-sm shadow border border-white/10">
                <span className="mr-2" aria-hidden="true">
                  👑
                </span>
                <span id="header-score">5,000 pts</span>
              </div>
              <div className="rounded-full bg-indigo-900/70 px-4 py-2 text-sm shadow border border-white/10">
                <span className="mr-2" aria-hidden="true">
                  ⭐
                </span>
                <span id="header-level">Level 15</span>
              </div>
              <button
                id="header-music"
                className="rounded-full bg-rose-600/80 px-4 py-2 text-sm shadow border border-white/10 hover:bg-rose-600 transition"
                aria-label="Toggle music"
              >
                <span className="mr-2" aria-hidden="true">
                  🎵
                </span>
                <span>Music On</span>
              </button>
            </div>
          </div>
        </header>

        {/* Working Game */}
        <Game />
      </div>
    </main>
  )
}
