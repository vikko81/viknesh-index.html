// Minimal DOM-based particle effect for clears (hook up later if desired)
export function burst(container, x, y) {
  if (!container) return
  const count = 8
  for (let i = 0; i < count; i++) {
    const el = document.createElement("span")
    el.style.position = "absolute"
    el.style.left = `${x}px`
    el.style.top = `${y}px`
    el.style.width = "6px"
    el.style.height = "6px"
    el.style.borderRadius = "9999px"
    el.style.background = "rgba(245,158,11,0.9)"
    el.style.transform = `translate(-50%, -50%)`
    el.style.pointerEvents = "none"
    container.appendChild(el)
    const dx = (Math.random() - 0.5) * 60
    const dy = (Math.random() - 0.5) * 60
    const duration = 400 + Math.random() * 300
    el.animate([{ transform: `translate(${dx}px, ${dy}px)` }, { opacity: 0 }], {
      duration,
      easing: "ease-out",
      fill: "forwards",
    }).onfinish = () => el.remove()
  }
}
