// Reserved for future complex movement; CSS handles small transitions for now.
export function noop() {}
