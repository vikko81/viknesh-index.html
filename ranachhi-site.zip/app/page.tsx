"use client"

import { Button } from "@/components/ui/button"

export default function HomePage() {
  return (
    <main>
      <Header />
      <Hero />
      <Features />
      <CTA />
      <Footer />
    </main>
  )
}

function Header() {
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="mx-auto max-w-5xl px-4 py-3 flex items-center justify-between">
        <a href="/" className="text-xl font-semibold tracking-wide text-gray-900" aria-label="Ranachhi Home">
          Ranachhi
        </a>
        <nav aria-label="Primary navigation" className="flex items-center gap-4">
          <a href="#features" className="text-sm text-gray-600 hover:text-gray-900">
            Features
          </a>
          <a href="#contact" className="text-sm text-gray-600 hover:text-gray-900">
            Contact
          </a>
        </nav>
      </div>
    </header>
  )
}

function Hero() {
  return (
    <section className="bg-blue-700 text-white">
      <div className="mx-auto max-w-5xl px-4 py-16 flex flex-col items-center gap-5">
        <h1 className="text-pretty text-center text-4xl md:text-5xl font-semibold leading-tight">
          Ranachhi — Simple, Fast, and Reliable
        </h1>
        <p className="max-w-2xl text-center text-white/90 leading-relaxed">
          Ek saaf, tez aur future‑ready website. Best practices ke saath banayi gayi, taaki aage koi dikkat na ho.
        </p>
        <div className="flex items-center gap-3">
          <Button className="bg-white text-blue-800 hover:bg-white/90">Get Started</Button>
          <a
            href="#features"
            className="underline underline-offset-4 text-white/90 hover:text-white"
            aria-label="See features"
          >
            See Features
          </a>
        </div>
      </div>
    </section>
  )
}

function Features() {
  return (
    <section id="features" className="bg-white">
      <div className="mx-auto max-w-5xl px-4 py-14">
        <h2 className="text-2xl font-semibold text-gray-900 text-pretty">Why choose Ranachhi?</h2>
        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-3">
          <FeatureCard title="Blue Brand" body="Solid blue hero for strong identity and accessible contrast." />
          <FeatureCard title="Mobile‑First" body="Clean layout, semantic HTML, and ARIA for accessibility." />
          <FeatureCard title="Future‑Ready" body="Simple components, easy to expand with new pages." />
        </div>
      </div>
    </section>
  )
}

function FeatureCard({ title, body }: { title: string; body: string }) {
  return (
    <article className="rounded-lg border border-gray-200 bg-white p-5">
      <h3 className="text-lg font-medium text-gray-900">{title}</h3>
      <p className="mt-2 text-gray-600 leading-relaxed">{body}</p>
    </article>
  )
}

function CTA() {
  return (
    <section id="contact" className="bg-blue-50">
      <div className="mx-auto max-w-5xl px-4 py-12 text-center">
        <h2 className="text-2xl font-semibold text-gray-900 text-pretty">Need custom pages or a contact form?</h2>
        <p className="mt-2 text-gray-700 leading-relaxed">
          Bataiye kaun‑kaun se sections chahiye (About, Services, Contact). Main turant add kar dunga.
        </p>
        <div className="mt-5 flex justify-center">
          <a
            href="mailto:hello@example.com"
            className="inline-flex items-center rounded-md bg-blue-700 px-4 py-2 text-white hover:bg-blue-800"
          >
            Email Us
          </a>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="mx-auto max-w-5xl px-4 py-6 flex items-center justify-between">
        <span className="text-sm text-gray-700">© {new Date().getFullYear()} Ranachhi</span>
        <nav aria-label="Footer" className="flex items-center gap-4 text-sm">
          <a href="#" className="text-gray-600 hover:text-gray-900">
            Privacy
          </a>
          <a href="#" className="text-gray-600 hover:text-gray-900">
            Terms
          </a>
        </nav>
      </div>
    </footer>
  )
}
