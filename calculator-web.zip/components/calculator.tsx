"use client"

import * as React from "react"
import { cn } from "@/lib/utils"
import { evaluateExpression, percentifyLastNumber } from "@/lib/calc"

type HistoryItem = {
  id: string
  expr: string
  result: string
  ts: number
}

const MAX_HISTORY = 50
const HISTORY_KEY = "calc_history_v1"

export default function Calculator() {
  const [expr, setExpr] = React.useState<string>("")
  const [result, setResult] = React.useState<string>("0")
  const [showHistory, setShowHistory] = React.useState(false)
  const [history, setHistory] = React.useState<HistoryItem[]>([])

  // Load & persist history
  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY)
      if (raw) setHistory(JSON.parse(raw))
    } catch {}
  }, [])
  React.useEffect(() => {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history))
    } catch {}
  }, [history])

  const isOp = (c: string) => ["+", "-", "×", "÷"].includes(c)

  function append(value: string) {
    if (isOp(value)) {
      if (!expr && value !== "-") return
      if (expr && isOp(expr.at(-1) as string)) {
        setExpr((s) => s.slice(0, -1) + value)
        return
      }
    }
    if (value === ".") {
      const parts = expr.split(/[+\-×÷]/)
      const last = parts[parts.length - 1]
      if (last.includes(".")) return
      if (!expr || isOp(expr.at(-1) as string)) {
        setExpr((s) => s + "0.")
        return
      }
    }
    setExpr((s) => s + value)
  }

  function handleBackspace() {
    if (!expr) return
    setExpr((s) => s.slice(0, -1))
  }

  function handleClear() {
    setExpr("")
    setResult("0")
  }

  function handlePercent() {
    if (!expr) return
    setExpr(percentifyLastNumber(expr))
  }

  function handleEqual() {
    if (!expr) return
    const safeExpr = expr.replace(/×/g, "*").replace(/÷/g, "/")
    try {
      const val = evaluateExpression(safeExpr)
      if (!isFinite(val)) throw new Error("Invalid")
      const formatted = String(+Number.parseFloat(String(val)).toPrecision(12))
        .replace(/\.0+$/, "")
        .replace(/(\.\d*?[1-9])0+$/, "$1")
      setResult(formatted)
      setExpr(formatted) // allow chaining
      pushHistory(expr, formatted)
    } catch {
      setResult("Error")
    }
  }

  function pushHistory(e: string, r: string) {
    const item: HistoryItem = {
      id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
      expr: e,
      result: r,
      ts: Date.now(),
    }
    setHistory((prev) => [item, ...prev].slice(0, MAX_HISTORY))
  }

  function loadFromHistory(h: HistoryItem) {
    setExpr(h.result)
    setShowHistory(false)
  }

  function deleteHistoryItem(id: string) {
    setHistory((prev) => prev.filter((x) => x.id !== id))
  }

  function clearHistory() {
    setHistory([])
  }

  const keys: { label: string; onPress: () => void; variant?: "op" | "eq" | "util"; grow?: boolean }[] = [
    { label: "AC", onPress: handleClear, variant: "util" },
    { label: "⌫", onPress: handleBackspace, variant: "util" },
    { label: "%", onPress: handlePercent, variant: "util" },
    { label: "÷", onPress: () => append("÷"), variant: "op" },

    { label: "7", onPress: () => append("7") },
    { label: "8", onPress: () => append("8") },
    { label: "9", onPress: () => append("9") },
    { label: "×", onPress: () => append("×"), variant: "op" },

    { label: "4", onPress: () => append("4") },
    { label: "5", onPress: () => append("5") },
    { label: "6", onPress: () => append("6") },
    { label: "−", onPress: () => append("-"), variant: "op" },

    { label: "1", onPress: () => append("1") },
    { label: "2", onPress: () => append("2") },
    { label: "3", onPress: () => append("3") },
    { label: "+", onPress: () => append("+"), variant: "op" },

    { label: "0", onPress: () => append("0"), grow: true },
    { label: ".", onPress: () => append(".") },
    { label: "=", onPress: handleEqual, variant: "eq" },
  ]

  return (
    <div className="flex flex-col gap-4">
      {/* Display */}
      <div className="rounded-2xl border border-gray-200 p-4">
        <div className="mb-2 flex items-center justify-between">
          <div className="text-sm text-gray-500">Expression</div>
          <button
            onClick={() => setShowHistory((s) => !s)}
            aria-expanded={showHistory}
            className="rounded-full border border-gray-200 px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
          >
            History
          </button>
        </div>
        <div className="min-h-[48px] text-right text-xl text-gray-700" aria-live="polite">
          {expr || "0"}
        </div>
        <div className="mt-1 text-right text-4xl font-semibold">{result}</div>
      </div>

      {/* Keypad */}
      <div className="grid grid-cols-4 gap-2">
        {keys.map((k, i) => {
          const base =
            "h-14 rounded-full text-lg font-medium focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"
          const cls =
            k.variant === "eq"
              ? "bg-orange-500 text-white hover:bg-orange-600"
              : k.variant === "op"
                ? "bg-white text-orange-500 border border-orange-200 hover:bg-orange-50"
                : k.variant === "util"
                  ? "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
                  : "bg-white text-gray-900 border border-gray-200 hover:bg-gray-50"

          return (
            <button
              key={i}
              onClick={k.onPress}
              className={cn(base, cls, k.grow ? "col-span-2" : "")}
              aria-label={`Key ${k.label}`}
            >
              {k.label}
            </button>
          )
        })}
      </div>

      {/* Collapsible History */}
      {showHistory && (
        <section aria-label="Calculation History" className="rounded-2xl border border-gray-200 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-semibold">History</h2>
            {history.length > 0 && (
              <button
                onClick={clearHistory}
                className="rounded-md border border-gray-200 px-3 py-1 text-sm text-gray-700 hover:bg-gray-50"
              >
                Clear all
              </button>
            )}
          </div>
          {history.length === 0 ? (
            <p className="text-sm text-gray-500">No calculations yet.</p>
          ) : (
            <ul className="space-y-2">
              {history.map((h) => (
                <li key={h.id} className="flex items-start justify-between rounded-lg border border-gray-200 p-3">
                  <button onClick={() => loadFromHistory(h)} className="text-left">
                    <div className="text-xs text-gray-500">{h.expr}</div>
                    <div className="text-base font-medium">{h.result}</div>
                  </button>
                  <button
                    onClick={() => deleteHistoryItem(h.id)}
                    className="rounded-md px-2 py-1 text-sm text-gray-600 hover:bg-gray-100"
                    aria-label="Delete history item"
                  >
                    Delete
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      <p className="sr-only">
        Color palette: primary orange for actions; neutrals (white, gray, black) for background and text to meet WCAG
        contrast.
      </p>
    </div>
  )
}
