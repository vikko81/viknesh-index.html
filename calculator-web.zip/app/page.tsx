import Calculator from "@/components/calculator"

export default function Page() {
  return (
    <main className="min-h-dvh bg-white text-gray-900">
      <div className="mx-auto w-full max-w-sm px-4 py-6">
        <header className="mb-6 flex items-center justify-between">
          <h1 className="text-pretty text-2xl font-semibold">Calculator</h1>
          {/* History toggle is inside the Calculator component */}
        </header>
        <Calculator />
      </div>
    </main>
  )
}
