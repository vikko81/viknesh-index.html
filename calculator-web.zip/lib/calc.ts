// Safe arithmetic evaluator (no eval). Supports +, -, *, / with correct precedence
// and a helper to convert the last number to its percentage.

const precedence: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2 }

export function evaluateExpression(input: string): number {
  const tokens = tokenize(input)
  const output: (number | string)[] = []
  const ops: string[] = []

  for (const t of tokens) {
    if (typeof t === "number") {
      output.push(t)
    } else if (t in precedence) {
      while (ops.length && precedence[ops[ops.length - 1]] >= precedence[t]) {
        output.push(ops.pop() as string)
      }
      ops.push(t)
    } else {
      throw new Error("Bad token")
    }
  }
  while (ops.length) output.push(ops.pop() as string)

  const stack: number[] = []
  for (const t of output) {
    if (typeof t === "number") {
      stack.push(t)
    } else {
      const b = stack.pop()
      const a = stack.pop()
      if (a === undefined || b === undefined) throw new Error("Bad expression")
      switch (t) {
        case "+":
          stack.push(a + b)
          break
        case "-":
          stack.push(a - b)
          break
        case "*":
          stack.push(a * b)
          break
        case "/":
          stack.push(b === 0 ? Number.POSITIVE_INFINITY : a / b)
          break
      }
    }
  }
  if (stack.length !== 1) throw new Error("Bad evaluation")
  return stack[0]
}

function tokenize(s: string): (number | string)[] {
  const str = s.replace(/\s+/g, "")
  const out: (number | string)[] = []
  let i = 0
  while (i < str.length) {
    const ch = str[i]
    if (/[0-9.]/.test(ch)) {
      let j = i + 1
      while (j < str.length && /[0-9.]/.test(str[j])) j++
      out.push(Number.parseFloat(str.slice(i, j)))
      i = j
    } else if (/[+\-*/]/.test(ch)) {
      // unary minus
      if (ch === "-" && (out.length === 0 || typeof out[out.length - 1] !== "number")) {
        let j = i + 1
        while (j < str.length && /[0-9.]/.test(str[j])) j++
        out.push(-Number.parseFloat(str.slice(i + 1, j)))
        i = j
      } else {
        out.push(ch)
        i++
      }
    } else {
      throw new Error("Invalid char")
    }
  }
  return out
}

export function percentifyLastNumber(expr: string): string {
  const m = expr.match(/(\d+(\.\d+)?)$/)
  if (!m) return expr
  const num = Number.parseFloat(m[1])
  const pct = (num / 100).toString()
  return expr.slice(0, expr.length - m[1].length) + pct
}
